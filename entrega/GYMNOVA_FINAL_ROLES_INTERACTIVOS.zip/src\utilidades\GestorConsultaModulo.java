package utilidades;

import controlador.AutorizacionControlador;
import controlador.ConsultaModuloControlador;
import controlador.EditorRegistroControlador;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import vista.PnlEditorRegistro;

/**
 * Conecta la tabla común de los módulos con los controladores CRUD existentes.
 * No crea componentes visuales; todos se conservan en los formularios Design.
 */
public class GestorConsultaModulo {

    private final JPanel padre;
    private final JComboBox<String> selector;
    private final JTable tabla;
    private final JTextField buscador;
    private final JLabel cantidad;
    private final String permisoModulo;
    private final Map<String, String> controladores;
    private final ConsultaModuloControlador consultaControlador;
    private final AutorizacionControlador autorizacionControlador;
    private List<?> registros;

    public GestorConsultaModulo(
            JPanel padre,
            JComboBox<String> selector,
            JTable tabla,
            JTextField buscador,
            JLabel cantidad,
            String permisoModulo,
            Map<String, String> controladores
    ) {
        this.padre = padre;
        this.selector = selector;
        this.tabla = tabla;
        this.buscador = buscador;
        this.cantidad = cantidad;
        this.permisoModulo = permisoModulo;
        this.controladores = new LinkedHashMap<>(controladores);
        this.consultaControlador = new ConsultaModuloControlador();
        this.autorizacionControlador = new AutorizacionControlador();
        this.registros = new ArrayList<>();
    }

    public static Map<String, String> controladoresPara(String modulo) {
        Map<String, String> mapa = new LinkedHashMap<>();

        switch (modulo.toUpperCase()) {
            case "PERSONAL" -> {
                mapa.put("Empleados", "EmpleadoControlador");
                mapa.put("Entrenadores", "EntrenadorControlador");
                mapa.put("Nutricionistas", "NutricionistaControlador");
                mapa.put("Especialidades", "EspecialidadControlador");
                mapa.put("Especialidades de entrenador", "EntrenadorEspecialidadControlador");
                mapa.put("Certificaciones de entrenador", "EntrenadorCertificacionControlador");
                mapa.put("Certificaciones de nutricionista", "NutricionistaCertificacionControlador");
                mapa.put("Provincias", "ProvinciaControlador");
                mapa.put("Asignaciones laborales", "TrabajaControlador");
            }
            case "MEMBRESIAS" -> {
                mapa.put("Membresias", "MembresiaControlador");
                mapa.put("Tipos de membresia", "TipoMembresiaControlador");
                mapa.put("Beneficios", "TipoMembresiaBeneficioControlador");
                mapa.put("Congelaciones", "CongelacionControlador");
                mapa.put("Descuentos", "DescuentoControlador");
            }
            case "ACCESO" -> {
                mapa.put("Reservas", "ReservaControlador");
                mapa.put("Asistencias", "AsistenciaControlador");
                mapa.put("Clases grupales", "ClaseGrupalControlador");
                mapa.put("Clases especiales", "ClaseEspecialControlador");
                mapa.put("Horarios", "HorarioControlador");
            }
            case "RUTINAS" -> {
                mapa.put("Rutinas", "RutinaControlador");
                mapa.put("Asignaciones", "AsignacionRutinaControlador");
                mapa.put("Ejercicios", "EjercicioControlador");
                mapa.put("Grupos musculares", "GrupoMuscularControlador");
                mapa.put("Dias de entrenamiento", "RutinaDiaEntrenamientoControlador");
                mapa.put("Progreso", "ProgresoRutinaControlador");
                mapa.put("Equipos requeridos", "RequiereEquipoControlador");
                mapa.put("Recursos multimedia", "EjercicioRecursoMultimediaControlador");
                mapa.put("Ejercicios de rutina", "ContieneEjercicioControlador");
            }
            case "SALUD" -> {
                mapa.put("Evaluaciones fisicas", "EvaluacionFisicaControlador");
                mapa.put("Mediciones corporales", "MedicionCorporalControlador");
                mapa.put("Indicadores de salud", "IndicadorSaludControlador");
                mapa.put("Resultados", "ResultadoIndicadorControlador");
                mapa.put("Recomendaciones", "RecomendacionControlador");
                mapa.put("Objetivos fitness", "ObjetivoFitnessControlador");
                mapa.put("Objetivos del cliente", "ClienteObjetivoControlador");
            }
            case "NUTRICION" -> {
                mapa.put("Planes nutricionales", "PlanNutricionalControlador");
                mapa.put("Alimentos", "AlimentoControlador");
                mapa.put("Alimentos incluidos", "IncluyeAlimentoControlador");
                mapa.put("Alergenos", "AlimentoAlergenoControlador");
                mapa.put("Nutricionistas", "NutricionistaControlador");
                mapa.put("Certificaciones", "NutricionistaCertificacionControlador");
            }
            case "FINANZAS" -> {
                mapa.put("Pagos", "PagoControlador");
                mapa.put("Facturas", "FacturaControlador");
                mapa.put("Detalle de factura", "DetalleFacturaControlador");
                mapa.put("Metodos de pago", "MetodoPagoControlador");
                mapa.put("Comprobantes", "ComprobanteControlador");
                mapa.put("Descuentos aplicados", "AplicaDescuentoControlador");
            }
            case "INVENTARIO" -> {
                mapa.put("Productos", "ProductoControlador");
                mapa.put("Categorias", "CategoriaProductoControlador");
                mapa.put("Proveedores", "ProveedorControlador");
                mapa.put("Compras", "CompraControlador");
                mapa.put("Detalle de compra", "DetalleCompraControlador");
                mapa.put("Equipos", "EquipoControlador");
                mapa.put("Tipos de equipo", "TipoEquipoControlador");
                mapa.put("Mantenimientos", "MantenimientoControlador");
                mapa.put("Tipos de mantenimiento", "TipoMantenimientoControlador");
                mapa.put("Productos por proveedor", "SuministraProductoControlador");
            }
            case "REPORTES" -> {
                mapa.put("Clientes", "ClienteControlador");
                mapa.put("Membresias", "MembresiaControlador");
                mapa.put("Accesos", "AsistenciaControlador");
                mapa.put("Rutinas", "AsignacionRutinaControlador");
                mapa.put("Salud", "EvaluacionFisicaControlador");
                mapa.put("Nutricion", "PlanNutricionalControlador");
                mapa.put("Finanzas", "PagoControlador");
                mapa.put("Inventario", "ProductoControlador");
                mapa.put("Personal", "EmpleadoControlador");
                mapa.put("Auditoria", "BitacoraControlador");
            }
            default -> {
                // El módulo no utiliza el gestor de consultas CRUD.
            }
        }

        return mapa;
    }

    public void cargar() {
        String controlador = controladorActual();
        if (controlador == null) {
            return;
        }

        String rol = SesionUsuario.haySesionActiva()
                ? SesionUsuario.getUsuarioActual().getNombreRol()
                : "";
        Long idPersona = SesionUsuario.haySesionActiva()
                ? SesionUsuario.getUsuarioActual().getIdPersona()
                : null;

        registros = consultaControlador.listarParaSesion(
                controlador,
                buscador.getText(),
                rol,
                idPersona
        );

        String[] columnas = registros.isEmpty()
                ? new String[]{"Información"}
                : consultaControlador.obtenerColumnas(registros.get(0));
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        for (Object registro : registros) {
            modelo.addRow(consultaControlador.obtenerFila(registro));
        }

        tabla.setModel(modelo);
        cantidad.setText(
                registros.size()
                + (registros.size() == 1
                        ? " registro encontrado"
                        : " registros encontrados")
        );

        if (!consultaControlador.getMensaje().isBlank()
                && registros.isEmpty()) {
            cantidad.setText(consultaControlador.getMensaje());
        }
    }

    public Object getSeleccionado() {
        int filaVista = tabla.getSelectedRow();
        if (filaVista < 0) {
            return null;
        }
        int filaModelo = tabla.convertRowIndexToModel(filaVista);
        return filaModelo < registros.size()
                ? registros.get(filaModelo)
                : null;
    }

    public boolean nuevo() {
        if (!verificarPermiso("CREAR")) {
            return false;
        }
        return abrirEditor(false);
    }

    public boolean modificar() {
        if (!verificarPermiso("MODIFICAR")) {
            return false;
        }
        if (getSeleccionado() == null) {
            mostrarAdvertencia("Seleccione un registro de la tabla.");
            return false;
        }
        return abrirEditor(true);
    }

    public boolean desactivar() {
        if (!verificarPermiso("DESACTIVAR")) {
            return false;
        }
        boolean correcto = consultaControlador.desactivar(
                controladorActual(),
                getSeleccionado()
        );
        informarResultado(correcto, "Registro desactivado correctamente.");
        return correcto;
    }

    public boolean eliminar() {
        if (!esAdministrador() || !verificarPermiso("ELIMINAR")) {
            mostrarAdvertencia(
                    "Solo el administrador puede eliminar definitivamente."
            );
            return false;
        }
        if (JOptionPane.showConfirmDialog(
                padre,
                "¿Eliminar definitivamente el registro seleccionado?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        ) != JOptionPane.YES_OPTION) {
            return false;
        }

        boolean correcto = consultaControlador.eliminarDefinitivamente(
                controladorActual(),
                getSeleccionado()
        );
        informarResultado(correcto, "Registro eliminado correctamente.");
        return correcto;
    }

    public boolean verificarPermiso(String accion) {
        if (!accionPermitidaPorRol(accion)) {
            mostrarAdvertencia(
                    "El rol actual no puede realizar esta operacion en este submodulo."
            );
            return false;
        }
        if (autorizacionControlador.tienePermiso(permisoModulo, accion)) {
            return true;
        }
        mostrarAdvertencia(autorizacionControlador.getMensaje());
        return false;
    }

    private boolean accionPermitidaPorRol(String accion) {
        if (!SesionUsuario.haySesionActiva()) {
            return false;
        }
        String rol = SesionUsuario.getUsuarioActual().getNombreRol();
        rol = rol == null ? "" : rol.trim().toUpperCase();
        String actual = controladorActual();

        if ("ADMINISTRADOR".equals(rol) || "RECEPCIONISTA".equals(rol)
                || "VER".equalsIgnoreCase(accion)) {
            return true;
        }
        if ("ELIMINAR".equalsIgnoreCase(accion)) {
            return false;
        }
        if ("CLIENTE".equals(rol)) {
            return java.util.Set.of(
                    "ReservaControlador", "ProgresoRutinaControlador"
            ).contains(actual);
        }
        if ("ENTRENADOR".equals(rol)) {
            return java.util.Set.of(
                    "RutinaControlador", "AsignacionRutinaControlador",
                    "ContieneEjercicioControlador",
                    "RutinaDiaEntrenamientoControlador",
                    "ProgresoRutinaControlador",
                    "EvaluacionFisicaControlador",
                    "MedicionCorporalControlador",
                    "ResultadoIndicadorControlador",
                    "RecomendacionControlador"
            ).contains(actual);
        }
        if ("NUTRICIONISTA".equals(rol)) {
            return java.util.Set.of(
                    "PlanNutricionalControlador",
                    "IncluyeAlimentoControlador",
                    "AlimentoControlador",
                    "AlimentoAlergenoControlador",
                    "MedicionCorporalControlador",
                    "ResultadoIndicadorControlador",
                    "RecomendacionControlador"
            ).contains(actual);
        }
        return false;
    }

    public void limpiarSeleccion() {
        tabla.clearSelection();
    }

    private boolean abrirEditor(boolean modificacion) {
        EditorRegistroControlador editorControlador
                = new EditorRegistroControlador();
        PnlEditorRegistro editor = new PnlEditorRegistro();

        if (!editorControlador.preparar(
                controladorActual(),
                modificacion ? getSeleccionado() : null,
                modificacion,
                editor
        )) {
            mostrarAdvertencia(editorControlador.getMensaje());
            return false;
        }

        int opcion = JOptionPane.showConfirmDialog(
                padre,
                editor,
                modificacion ? "Modificar registro" : "Nuevo registro",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );
        if (opcion != JOptionPane.OK_OPTION) {
            return false;
        }

        boolean correcto = editorControlador.guardar(editor);
        if (correcto) {
            JOptionPane.showMessageDialog(
                    padre,
                    editorControlador.getMensaje(),
                    "GYMNOVA",
                    JOptionPane.INFORMATION_MESSAGE
            );
            cargar();
        } else {
            mostrarAdvertencia(editorControlador.getMensaje());
        }
        return correcto;
    }

    private String controladorActual() {
        Object item = selector.getSelectedItem();
        return item == null ? null : controladores.get(item.toString());
    }

    private void informarResultado(boolean correcto, String mensajeCorrecto) {
        if (correcto) {
            JOptionPane.showMessageDialog(
                    padre,
                    mensajeCorrecto,
                    "GYMNOVA",
                    JOptionPane.INFORMATION_MESSAGE
            );
            cargar();
        } else {
            mostrarAdvertencia(consultaControlador.getMensaje());
        }
    }

    private void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(
                padre,
                mensaje == null || mensaje.isBlank()
                        ? "No fue posible completar la operación."
                        : mensaje,
                "Atención",
                JOptionPane.WARNING_MESSAGE
        );
    }

    private boolean esAdministrador() {
        return SesionUsuario.haySesionActiva()
                && "Administrador".equalsIgnoreCase(
                        SesionUsuario.getUsuarioActual().getNombreRol()
                );
    }
}
