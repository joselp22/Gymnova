/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Usuario
 */

public final class ConexionPostgreSQL {

    private static final String URL
            = "jdbc:postgresql://localhost:5432/gymnova_db";

    private static final String USUARIO = "postgres";

    private static final String CONTRASENA = "12345";

    private ConexionPostgreSQL() {
        // Evita crear objetos de esta clase.
    }

    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(
                URL,
                USUARIO,
                CONTRASENA
        );
    }
}
