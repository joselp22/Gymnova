# GYMNOVA - entrega Java revisada

Proyecto compatible con NetBeans 24, JDK 17, Java Swing, Ant y PostgreSQL.

## Cobertura

- Login y sesion compartida con nombre de usuario y rol.
- Un `FrmPrincipal` que selecciona cinco formularios de inicio independientes:
  `PnlInicioAdministrador`, `PnlInicioRecepcionista`,
  `PnlInicioEntrenador`, `PnlInicioNutricionista` y `PnlInicioCliente`.
- Navegacion no administrativa orientada a tareas: el cliente consulta rutina,
  ejercicios, progreso, membresia, reservas y nutricion; el entrenador trabaja
  con clientes, planificacion y evaluaciones; el nutricionista con planes,
  alertas y seguimiento; recepcion con accesos, agenda, membresias y caja.
- Los CRUD no desaparecen: el Administrador entra directamente a la gestion y
  los otros roles abren el detalle desde la portada operativa cuando tienen el
  permiso correspondiente.
- Identidad visual y contenido operativo diferente para cada rol: paneles
  administrativos oscuros, paneles profesionales claros y portal del cliente.
- Dashboard con indicadores y actividad consultados desde PostgreSQL segun el
  rol autenticado.
- CRUD de Personas, Clientes y Empleados.
- Gestion de Usuarios, Roles, Permisos, Rol-Permiso y Bitacora.
- Gestion de Personal complementaria: entrenadores, nutricionistas,
  especialidades, certificaciones, provincias y asignaciones laborales.
- Submodulos de Membresias, Acceso, Rutinas, Salud, Nutricion, Finanzas e
  Inventario enlazados con sus controladores y DAO existentes.
- Reportes con consulta, exportacion CSV e impresion.
- Configuracion de cuenta y cambio de clave.
- Eliminacion definitiva visible solo para Administrador y protegida por las
  relaciones de PostgreSQL; los demas roles utilizan desactivacion logica.
- Cedula, identificadores y codigos automaticos no se modifican.

## Formularios Design

Las 23 vistas Swing conservan su archivo `.form` valido. El formulario
reutilizable `PnlEditorRegistro.form` contiene los campos visuales para las
altas y modificaciones de catalogos y movimientos. La logica permanece en
controladores y utilidades, sin JDBC dentro de las vistas.

## Verificacion realizada

- `Clean and Build`: exitoso.
- JAR generado: `dist/GYMNOVA_FINAL.jar`.
- 23 pares `.java`/`.form` y 23 XML validos.
- 62 modelos, 63 DAO y 67 controladores.
- Prueba de construccion: 14 paneles principales.
- Prueba de dashboard: 5 formularios de rol construidos y renderizados.
- Prueba de experiencias: 19 portadas operativas construidas y tres ejemplos
  renderizados (`Mi rutina`, planificador del entrenador y nutricion).

La base de datos no fue modificada durante esta fase. Los roles, permisos,
usuarios de prueba y datos maestros se completan en la siguiente fase SQL.
